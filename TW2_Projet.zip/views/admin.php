<section id="adminsec">

<h2>Admin</h2>

<ul>
	<li  ><a id="gestion" href="adminUsers">Gestion des utilisateurs</a></li>
	<li id="cata" ><a href="adminCollection">Catalogue commun</a></li>
</ul>

</section>